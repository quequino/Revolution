Syntax is fairly straight forward, plugin folder followed by valid countries (2 letter code)
e.g. plugin.video.iplayer=UK, AU, US


* indicates any country (will be picked at random)
e.g. plugin.video.1channel=*


To indicate that you want VPNicity to present you with a list of cities, use +CITY after country code
e.g. plugin.video.iplayer=UK+CITY